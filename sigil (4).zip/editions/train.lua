
SMODS.Shader({ key = 'laminated', path = 'laminated.fs' })

SMODS.Edition {
    key = 'train',
    shader = 'laminated',
    in_shop = false,
    apply_to_float = false,
    badge_colour = HEX('362965'),
    disable_shadow = false,
    disable_base_shader = false,
    loc_txt = {
        name = 'Train',
        label = 'Train',
        text = {
            [1] = 'TRAIN'
        }
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    get_weight = function(self)
        return G.GAME.edition_rate * self.weight
    end,
    
    calculate = function(self, card, context)
        if context.pre_joker or (context.main_scoring and context.cardarea == G.play) then
            local created_joker = true
            G.E_MANAGER:add_event(Event({
                func = function()
                    local joker_card = SMODS.add_card({ set = 'Joker', key = 'j_train' })
                    if joker_card then
                        joker_card:set_edition("e_negative", true)
                        joker_card:add_sticker('eternal', true)
                    end
                    
                    return true
                end
            }))
            return {
                message = created_joker and localize('k_plus_joker') or nil
            }
        end
    end
}