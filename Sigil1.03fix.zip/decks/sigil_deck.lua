
SMODS.Back {
    key = 'sigil_deck',
    pos = { x = 0, y = 0 },
    config = {
        extra = {
            odds = 2
        },
        consumables = {"c_sigil","c_sigil","c_sigil","c_sigil"},
    },
    loc_txt = {
        name = 'Sigil Deck',
        text = {
            [1] = 'Creates one copy of {C:blue}Sigil {}every round with a {C:uncommon}1/2{} chance'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
    calculate = function(self, card, context)
        if context.end_of_round and context.game_over == false and context.main_eval then
            if SMODS.pseudorandom_probability(card, 'group_0_b3208358', 1, card.ability.extra.odds, 'j_sigil_sigil_deck', false) then
                for i = 1, 1 do
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            
                            play_sound('timpani')
                            SMODS.add_card({ set = 'Spectral', key = 'c_sigil'
                            })
                            return true
                        end
                    }))
                end
                
            end
        end
    end,
    
}