
SMODS.Joker{ --Starfruit
    key = "starfruit",
    config = {
        extra = {
            source_rank_type = 'specific',
            source_ranks = '{"A", "2", "3", "4", "5", "6", "8", "9", "10", "K", "Q", "J", "7"}',
            target_rank = '"7"'
        }
    },
    loc_txt = {
        ['name'] = 'Starfruit',
        ['text'] = {
            [1] = 'Every card is considered as a {C:diamonds}7{}',
            [2] = '{C:green}1 in 7{} chance to get destroyed each round'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 0
    },
    display_size = {
        w = 71 * 1.2, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["sigil_sigil_jokers"] = true },
    
    calculate = function(self, card, context)
    end,
    
    add_to_deck = function(self, card, from_debuff)
        -- Combine ranks effect enabled
    end,
    
    remove_from_deck = function(self, card, from_debuff)
        -- Combine ranks effect disabled
    end
}


local card_get_id_ref = Card.get_id
function Card:get_id()
    local original_id = card_get_id_ref(self)
    if not original_id then return original_id end

    if next(SMODS.find_card("j_sigil_starfruit")) then
        local source_ids = {14, 2, 3, 4, 5, 6, 8, 9, 10, 13, 12, 11, 7}
        for _, source_id in pairs(source_ids) do
            if original_id == source_id then return 14 end
        end
    end
    return original_id
end
