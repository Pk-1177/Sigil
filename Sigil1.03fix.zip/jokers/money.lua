
SMODS.Joker{ --Money
    key = "money",
    config = {
        extra = {
            Moneyamount = 0.01
        }
    },
    loc_txt = {
        ['name'] = 'Money',
        ['text'] = {
            [1] = 'Gives {C:money}$0.01.{} {C:hearts}Doubles {}each round.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["sigil_sigil_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.Moneyamount}}
    end,
    
    calculate = function(self, card, context)
        if context.starting_shop  then
            local Moneyamount_value = card.ability.extra.Moneyamount
            return {
                
                func = function()
                    
                    local current_dollars = G.GAME.dollars
                    local target_dollars = G.GAME.dollars + Moneyamount_value
                    local dollar_value = target_dollars - current_dollars
                    ease_dollars(dollar_value)
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(Moneyamount_value), colour = G.C.MONEY})
                    return true
                end,
                extra = {
                    func = function()
                        card.ability.extra.Moneyamount = (card.ability.extra.Moneyamount) * 2
                        return true
                    end,
                    colour = G.C.MULT
                }
            }
        end
    end
}