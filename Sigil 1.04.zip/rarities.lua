SMODS.Rarity {
    key = "chaos",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0.131,
    badge_colour = HEX('4b0000'),
    loc_txt = {
        name = "Chaos"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}