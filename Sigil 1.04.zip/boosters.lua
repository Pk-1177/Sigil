
SMODS.Booster {
    key = 'chaos_pack',
    loc_txt = {
        name = "Chaos Pack",
        text = {
            [1] = '{C:hearts}Chaos{} shall {s:2}emerge{}'
        },
        group_name = "sigil_boosters"
    },
    config = { extra = 3, choose = 1 },
    cost = 10,
    weight = 1.35,
    atlas = "CustomBoosters",
    pos = { x = 0, y = 0 },
    kind = 'Chaos',
    group_key = "sigil_boosters",
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        return {
            set = "sigil_sigil_jokers",
            area = G.pack_cards,
            skip_materialize = true,
            soulable = true,
            key_append = "sigil_chaos_pack"
        }
    end,
    ease_background_colour = function(self)
        ease_colour(G.C.DYN_UI.MAIN, HEX("ff0606"))
        ease_background_colour({ new_colour = HEX('ff0606'), special_colour = HEX("ff0000"), contrast = 2 })
    end,
    particles = function(self)
        -- No particles for joker packs
        end,
    }
    