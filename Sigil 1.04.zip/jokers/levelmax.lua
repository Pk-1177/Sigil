
SMODS.Joker{ --LevelMax
    key = "levelmax",
    config = {
        extra = {
            repetitions = 5,
            repetitions2 = 5,
            hyperchips_n0 = 2,
            hyperchips_arrows0 = 4,
            hypermult_n0 = 2,
            hypermult_arrows0 = 4
        }
    },
    loc_txt = {
        ['name'] = 'LevelMax',
        ['text'] = {
            [1] = 'You\'ve won.',
            [2] = 'But at what cost?',
            [3] = 'The game\'s too effortless.',
            [4] = 'It isn\'t as fun as it was before.',
            [5] = 'An epiphany of darkness shall lie before you.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["sigil_sigil_levels"] = true },
    in_pool = function(self, args)
        return (
            not args 
            or args.source ~= 'sho' and args.source ~= 'buf' and args.source ~= 'jud' and args.source ~= 'sou' 
            or args.source == 'rif' or args.source == 'rta' or args.source == 'uta' or args.source == 'wra'
        )
        and true
    end,
    
    set_ability = function(self, card, initial)
        card:set_eternal(true)
        card:set_edition("e_negative", true)
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if true then
                for i = 1, 5 do
                    local my_pos = nil
                    for i = 1, #G.jokers.cards do
                        if G.jokers.cards[i] == card then
                            my_pos = i
                            break
                        end
                    end
                    local target_joker = nil
                    if my_pos and my_pos > 1 then
                        local joker = G.jokers.cards[my_pos - 1]
                        if true and not joker.getting_sliced then
                            target_joker = joker
                        end
                    end
                    
                    if target_joker then
                        if target_joker.ability.eternal then
                            target_joker.ability.eternal = nil
                        end
                        target_joker.getting_sliced = true
                        G.E_MANAGER:add_event(Event({
                            func = function()
                                target_joker:start_dissolve({G.C.RED}, nil, 1.6)
                                return true
                            end
                        }))
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "DARKNESS CONSUMES ALL", colour = G.C.RED})
                    end
                    
                end
            elseif true then
                for i = 1, 5 do
                    local my_pos = nil
                    for i = 1, #G.jokers.cards do
                        if G.jokers.cards[i] == card then
                            my_pos = i
                            break
                        end
                    end
                    local target_joker = nil
                    if my_pos and my_pos < #G.jokers.cards then
                        local joker = G.jokers.cards[my_pos + 1]
                        if true and not joker.getting_sliced then
                            target_joker = joker
                        end
                    end
                    
                    if target_joker then
                        if target_joker.ability.eternal then
                            target_joker.ability.eternal = nil
                        end
                        target_joker.getting_sliced = true
                        G.E_MANAGER:add_event(Event({
                            func = function()
                                target_joker:start_dissolve({G.C.RED}, nil, 1.6)
                                return true
                            end
                        }))
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "DARKNESS CONSUMES ALL", colour = G.C.RED})
                    end
                    
                end
            end
        end
        if context.individual and context.cardarea == G.play  then
            return {
                hyperchips = {
                    4,
                    2
                },
                extra = {
                    hypermult = {
                        4,
                        2
                    },
                    colour = G.C.DARK_EDITION
                }
            }
        end
    end
}