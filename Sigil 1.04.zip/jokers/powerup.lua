
SMODS.Joker{ --Powerup
    key = "powerup",
    config = {
        extra = {
            pb_bonus_fd99ada3 = 20,
            odds = 5,
            pb_mult_c71703dd = 1
        }
    },
    loc_txt = {
        ['name'] = 'Powerup',
        ['text'] = {
            [1] = 'Strengthens every card scored'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 50,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["sigil_sigil_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_sigil_powerup') 
        return {vars = {new_numerator, new_denominator}}
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if true then
                context.other_card.ability.perma_bonus = context.other_card.ability.perma_bonus or 0
                context.other_card.ability.perma_bonus = context.other_card.ability.perma_bonus + 20
                return {
                    extra = { message = "Powerup!", colour = G.C.CHIPS }, card = card
                    ,
                    func = function()
                        if SMODS.pseudorandom_probability(card, 'group_0_1ae2242c', 1, card.ability.extra.odds, 'j_sigil_powerup', false) then
                            context.other_card.ability.perma_mult = context.other_card.ability.perma_mult or 0
                            context.other_card.ability.perma_mult = context.other_card.ability.perma_mult + 1
                            
                        end
                        return true
                    end
                }
            end
        end
    end
}