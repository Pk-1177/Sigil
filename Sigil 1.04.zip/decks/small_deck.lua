
SMODS.Back {
    key = 'small_deck',
    pos = { x = 4, y = 0 },
    config = {
        extra = {
            remove_starting_cards_count0 = 52,
            repetitions = 5,
            add_starting_cards_count0 = 1,
            all_blinds_size0 = 0.1
        },
    },
    loc_txt = {
        name = 'Small deck',
        text = {
            [1] = 'Starts with 5 random cards, all blind requirements are multiplied by {C:hearts}X0.1{}'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
    apply = function(self, back)
        G.E_MANAGER:add_event(Event({
            func = function()
                for i=#G.deck.cards, 1, -1 do
                    G.deck.cards[i]:remove()
                end
                return true
            end
        }))
        for i = 1, 5 do
            G.E_MANAGER:add_event(Event({
                delay = 0.3,
                func = function()
                    local cards = {}
                    for i = 1, 1 do
                        local _rank = pseudorandom_element(SMODS.Ranks, 'add_random_rank').card_key
                        local _suit = nil
                        local new_card_params = { set = "Base", area = G.deck }
                    if _rank then new_card_params.rank = _rank end
                    if _suit then new_card_params.suit = _suit end
                        cards[i] = SMODS.add_card(new_card_params)
                    end
                    SMODS.calculate_context({ playing_card_added = true, cards = cards })
                    G.GAME.starting_deck_size = #G.playing_cards
                    return true
                end
            }))
            
        end
        G.E_MANAGER:add_event(Event({
            func = function()
                G.GAME.starting_params.ante_scaling = G.GAME.starting_params.ante_scaling * 0.1
                return true
            end
        }))
    end
}