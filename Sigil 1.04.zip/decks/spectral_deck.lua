
SMODS.Back {
    key = 'spectral_deck',
    pos = { x = 2, y = 0 },
    config = {
        extra = {
            repetitions = 10
        },
    },
    loc_txt = {
        name = 'Spectral Deck',
        text = {
            [1] = 'Start with 10 random {C:blue}Spectral cards{}'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
    apply = function(self, back)
        for i = 1, 10 do
            for i = 1, 1 do
                G.E_MANAGER:add_event(Event({
                    func = function()
                        
                        play_sound('timpani')
                        SMODS.add_card({ set = 'Spectral', 
                        })
                        return true
                    end
                }))
            end
            
        end
    end
}