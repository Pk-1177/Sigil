
SMODS.Back {
    key = 'sigil_copy',
    pos = { x = 5, y = 0 },
    config = {
        extra = {
            ante_value0 = 1
        },
    },
    loc_txt = {
        name = 'Sigil copy',
        text = {
            [1] = 'Every round, gives a Chaos pack and removes {C:money}$8{}'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
    calculate = function(self, card, context)
        if context.end_of_round and context.game_over == false and context.main_eval then
            local mod = 1
            G.E_MANAGER:add_event(Event({
                func = function()
                    ease_ante(mod)
                    G.GAME.round_resets.blind_ante = G.GAME.round_resets.blind_ante + mod
                    return true
                end,
            }))
        end
    end,
    
}