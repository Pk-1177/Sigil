
SMODS.Back {
    key = 'pink_deck',
    pos = { x = 3, y = 0 },
    config = {
        extra = {
            play_size0 = 1
        },
    },
    loc_txt = {
        name = 'Pink Deck',
        text = {
            [1] = '{C:tarot}+1{} Play size.'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
    apply = function(self, back)
        return {
            
            G.E_MANAGER:add_event(Event({
                func = function()
                    
                    
                    SMODS.change_play_limit(1)
                    return true
                end
            }))
        }
    end
}