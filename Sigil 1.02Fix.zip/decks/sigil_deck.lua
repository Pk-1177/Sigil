
SMODS.Back {
    key = 'sigil_deck',
    pos = { x = 0, y = 0 },
    config = {
        consumables = {"c_sigil","c_sigil","c_sigil","c_sigil"},
    },
    loc_txt = {
        name = 'Sigil Deck',
        text = {
            [1] = 'Start with four copies of {C:common}Sigil{}'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
    
}