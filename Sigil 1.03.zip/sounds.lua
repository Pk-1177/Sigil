SMODS.Sound{
    key="SUS",
    path="SUS.ogg",
    pitch=0.7,
    volume=1,
}