
SMODS.Seal {
    key = 'nocardhere',
    pos = { x = 0, y = 0 },
    badge_colour = HEX('000000'),
    loc_txt = {
        name = 'No card here',
        label = 'No card here',
        text = {
            [1] = '{C:green}Creates {} a random joker when scored, but'
        }
    },
    atlas = 'CustomSeals',
    unlocked = true,
    discovered = true,
    no_collection = false
}