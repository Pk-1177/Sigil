
SMODS.Joker{ --Water
    key = "water",
    config = {
        extra = {
            hand_size0 = 52,
            hand_size = 8
        }
    },
    loc_txt = {
        ['name'] = 'Water',
        ['text'] = {
            [1] = 'Beats {C:hearts}Fire{}, Loses to {C:green}Grass{}',
            [2] = 'Give hand size when a booster pack is skipped.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 10,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["sigil_sigil_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.skipping_booster  then
            return {
                
                func = function()
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Flowing!", colour = G.C.BLUE})
                    
                    G.hand:change_size(52)
                    return true
                end
            }
        end
        if context.end_of_round and context.game_over == false and context.main_eval  then
            return {
                
                func = function()
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Hand Limit set to "..tostring(8), colour = G.C.BLUE})
                    
                    local current_hand_size = (G.hand.config.card_limit or 0)
                    local target_hand_size = 8
                    local difference = target_hand_size - current_hand_size
                    G.hand:change_size(difference)
                    return true
                end
            }
        end
        if context.cardarea == G.jokers and context.joker_main  then
            if (function()
                for i, v in pairs(G.jokers.cards) do
                    if v.config.center.key == "j_sigil_fire" then 
                        return true
                    end
                end
            end)() then
                local target_joker = nil
                for i, joker in ipairs(G.jokers.cards) do
                    if joker.config.center.key == "j_sigil_fire" and not SMODS.is_eternal(joker) and not joker.getting_sliced then
                        target_joker = joker
                        break
                    end
                end
                
                if target_joker then
                    target_joker.getting_sliced = true
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            target_joker:start_dissolve({G.C.RED}, nil, 1.6)
                            return true
                        end
                    }))
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Destroyed!", colour = G.C.RED})
                end
            end
        end
    end
}