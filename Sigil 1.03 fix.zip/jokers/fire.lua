
SMODS.Joker{ --Fire
    key = "fire",
    config = {
        extra = {
            hypermult_n0 = 1.01,
            hypermult_arrows0 = 4
        }
    },
    loc_txt = {
        ['name'] = 'Fire',
        ['text'] = {
            [1] = 'Beats {C:green}grass,{} loses to {C:spectral}water.{}',
            [2] = '{C:hearts}^^^^1.1{} mult'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["sigil_sigil_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (function()
                for i, v in pairs(G.jokers.cards) do
                    if v.config.center.key == "j_sigil_grass" then 
                        return true
                    end
                end
            end)() then
                local target_joker = nil
                for i, joker in ipairs(G.jokers.cards) do
                    if joker.config.center.key == "j_sigil_grass" and not joker.getting_sliced then
                        target_joker = joker
                        break
                    end
                end
                
                if target_joker then
                    if target_joker.ability.eternal then
                        target_joker.ability.eternal = nil
                    end
                    target_joker.getting_sliced = true
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            target_joker:shatter({G.C.RED}, nil, 1.6)
                            return true
                        end
                    }))
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Victory!", colour = G.C.RED})
                end
            else
                return {
                    hypermult = {
                        4,
                        1.01
                    },
                    message = "^^^^1.05 Mult!"
                }
            end
        end
    end
}