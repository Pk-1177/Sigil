
SMODS.Enhancement {
    key = 'sus',
    pos = { x = 0, y = 0 },
    config = {
        extra = {
            xchips0 = 1.5,
            xmult0 = 1.5,
            odds = 5
        }
    },
    loc_txt = {
        name = 'SUS',
        text = {
            [1] = '{s:50}sus{}'
        }
    },
    atlas = 'CustomEnhancements',
    any_suit = false,
    replace_base_card = false,
    no_rank = false,
    no_suit = false,
    always_scores = false,
    unlocked = true,
    discovered = true,
    no_collection = false,
    weight = 5,
    loc_vars = function(self, info_queue, card)
        return {vars = {}}
    end,
    calculate = function(self, card, context)
        if context.main_scoring and context.cardarea == G.play then
            G.E_MANAGER:add_event(Event({
                func = function()
                    play_sound("sigil_SUS")
                    
                    return true
                end,
            }))
        end
        if context.main_scoring and context.cardarea == G.play then
            assert(SMODS.change_base(card, pseudorandom_element(SMODS.Suits, 'edit_card_suit').key, pseudorandom_element(SMODS.Ranks, 'edit_card_rank').key))
            return {
                x_chips = 1.5,
                extra = {
                    Xmult = 1.5,
                    extra = {
                        message = "Shapeshift!",
                        colour = G.C.BLUE
                    }
                }
            }
        end
        if context.main_scoring and context.cardarea == G.play then
            if SMODS.pseudorandom_probability(card, 'group_0_8c685eb3', 1, card.ability.extra.odds, 'j_sigil_sus', false) then
                local destructable_jokers = {}
                for i, joker in ipairs(G.jokers.cards) do
                    if not joker.ability.eternal and not joker.getting_sliced then
                        table.insert(destructable_jokers, joker)
                    end
                end
                local target_joker = #destructable_jokers > 0 and pseudorandom_element(destructable_jokers, pseudoseed('destroy_joker_enhanced')) or nil
                
                if target_joker then
                    target_joker.getting_sliced = true
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            target_joker:start_dissolve({G.C.RED}, nil, 1.6)
                            return true
                        end
                    }))
                end
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "There is an Imposter amoung us...", colour = G.C.RED})
            end
        end
    end
}